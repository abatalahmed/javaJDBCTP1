package ihm;

import java.util.List;
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

import Metier.Etudiant;






public class EtudiantModel extends AbstractTableModel{
	
private String[] nomColonnes=
new String[]{"Code","nom","prenom ","Email"};
private Vector<String[]> values=new Vector<String[]>();
			
		@Override
		public int getRowCount() {
			return values.size();
		}
		@Override
		public int getColumnCount() {
			return nomColonnes.length;
		}
		@Override
		public Object getValueAt(int rowIndex, int columnIndex) {
			return values.get(rowIndex)[columnIndex];
		}
		@Override
		public String getColumnName(int column) {
			// TODO Auto-generated method stub
			return nomColonnes[column];
		}
		
		
		public void chargerDonnees(List<Etudiant> etudiants){
			values=new Vector<String[]>();
			for(Etudiant e:etudiants)
		values.add(new String[]{
				String.valueOf(e.getIdEtudiant()),
				e.getNom(),
				e.getPrenom(),
				e.getEmail()
				});
			
			fireTableChanged(null);
		}
		}


