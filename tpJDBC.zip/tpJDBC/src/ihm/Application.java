package ihm;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Metier.Scolarite;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Application extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtMC;

	
	Scolarite metier;
	EtudiantModel model;
	JTable tableEtudiant;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Application frame = new Application();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Application() {
		
		
		
		metier=new Scolarite();
		model=new EtudiantModel();
		tableEtudiant=new JTable(model);
		setTitle("Scolarite");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Mot Cle :");
		lblNewLabel.setBounds(89, 17, 61, 16);
		contentPane.add(lblNewLabel);
		
		txtMC = new JTextField();
		txtMC.setBounds(181, 12, 130, 26);
		contentPane.add(txtMC);
		txtMC.setColumns(10);
		
		
		
		JScrollPane jsp = new JScrollPane(tableEtudiant);
		jsp.setBounds(34, 68, 395, 185);
		contentPane.add(jsp);
		
		model.chargerDonnees(metier.getAllEtudiants());
		
		
		
		
		JButton btnNewButton = new JButton("Rechercher");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mc=txtMC.getText();
				model.chargerDonnees(metier.getEtudiants(mc));
			}
		});
		btnNewButton.setBounds(327, 6, 117, 29);
		contentPane.add(btnNewButton);
		
	}
}
