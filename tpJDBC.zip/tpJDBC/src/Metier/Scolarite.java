package Metier;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class Scolarite {
	
	public List<Etudiant> getEtudiants(String mc){
		
		List<Etudiant> etudiants=new ArrayList<Etudiant>();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:8889/scolarite","tpgi","123456");
			
			PreparedStatement ps=conn.prepareStatement("select * from etudiants where nom like ? ");
			ps.setString(1,"%"+ mc+"%");
			
			ResultSet rs=ps.executeQuery();
			
			while (rs.next()) {
				Etudiant e=new Etudiant();
				e.setIdEtudiant(rs.getInt(1));
				e.setNom(rs.getString(2));
				e.setPrenom(rs.getString(3));
				e.setEmail(rs.getString(4));
				etudiants.add(e);
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
			
		return etudiants;
	}
	
	
	
public List<Etudiant> getAllEtudiants(){
		
		List<Etudiant> etudiants=new ArrayList<Etudiant>();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:8889/scolarite","tpgi","123456");
			
			PreparedStatement ps=conn.prepareStatement("select * from etudiants ");
			
			ResultSet rs=ps.executeQuery();
			
			while (rs.next()) {
				Etudiant e=new Etudiant();
				e.setIdEtudiant(rs.getInt(1));
				e.setNom(rs.getString(2));
				e.setPrenom(rs.getString(3));
				e.setEmail(rs.getString(4));
				etudiants.add(e);
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
			
		return etudiants;
	}

}
