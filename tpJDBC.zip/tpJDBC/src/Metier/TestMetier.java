package Metier;

import java.net.Socket;
import java.util.List;

public class TestMetier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Scolarite s=new Scolarite();
		
		
		List<Etudiant> etds=s.getEtudiants("A");
		
		System.out.println(etds.size());
	}

}
